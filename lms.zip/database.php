<?php  

$servername='localhost';
$username='root';
$password='';
$db='Library';

$connect= new mysqli($servername,$username,$password,$db);


//if($connect==true) echo "Connected"; else echo"Failed";


?>



