<?php
 
session_start();





Class Data{
	
		
		
		
		
	
		
		

	
	
	

	}
	
	
	



$ob=new Data();


?>