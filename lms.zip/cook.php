<?php   setcookie('Nme','Jason Bourne',time() + (86400 * 30));
					   if(isset($_COOKIE['Nme']) ) echo $_COOKIE['Nme'];
					   
					   ?>